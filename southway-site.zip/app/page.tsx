"use client";

import { motion } from "framer-motion";
import { Mail, Phone, MapPin } from "lucide-react";

export default function Page() {
  return (
    <div className="min-h-screen bg-black text-white font-light">

      <nav className="flex justify-between items-center px-12 py-8 border-b border-neutral-800">
        <h1 className="text-xl tracking-widest">SOUTHWAY</h1>
        <div className="space-x-6 text-sm uppercase">
          <a href="#home">Home</a>
          <a href="#services">Services</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <section className="h-[90vh] flex items-center justify-center text-center px-6">
        <div>
          <motion.h1 initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="text-5xl">
            Elite Management Consulting
          </motion.h1>
          <p className="mt-6 text-neutral-400 max-w-xl mx-auto">
            Southway partners with forward-thinking organizations to refine strategy and drive performance.
          </p>
        </div>
      </section>

      <section id="services" className="py-20 text-center">
        <h2 className="text-3xl mb-10">Our Expertise</h2>
        <div className="grid md:grid-cols-3 gap-8 px-6">
          <div className="border p-6">Strategic Advisory</div>
          <div className="border p-6">Operational Excellence</div>
          <div className="border p-6">Executive Performance</div>
        </div>
      </section>

      <section id="contact" className="py-20 text-center">
        <h2 className="text-3xl mb-10">Contact</h2>
        <div className="flex justify-center gap-10 text-sm">
          <div><Mail /> info@southwayconsulting.com</div>
          <div><Phone /> +971 585 188690</div>
          <div><MapPin /> Dubai</div>
        </div>
      </section>

    </div>
  );
}